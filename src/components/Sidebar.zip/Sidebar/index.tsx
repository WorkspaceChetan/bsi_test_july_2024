"use client";

import { Menu } from "@mui/icons-material";
import {
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import Link from "next/link";
import { useState } from "react";

const Sidebar = () => {
  const [open, setOpen] = useState(false);

  const toggleDrawer = (newOpen: boolean) => () => {
    setOpen(newOpen);
  };

  return (
    <>
      <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 2 }}>
        <IconButton onClick={toggleDrawer(true)}>
          <Menu />
        </IconButton>
        <Drawer open={open} onClose={toggleDrawer(false)} anchor="right">
          <Box sx={{ width: 250 }}>
            <List>
              <ListItem onClick={toggleDrawer(false)}>
                <ListItemButton>
                  <Box
                    component={Link}
                    href="/"
                    sx={{ textDecoration: "none", color: "black" }}
                  >
                    Users
                  </Box>
                </ListItemButton>
              </ListItem>
              <ListItem onClick={toggleDrawer(false)}>
                <ListItemButton>
                  <Box
                    component={Link}
                    href="/"
                    sx={{ textDecoration: "none", color: "black" }}
                  >
                    Favorite Users
                  </Box>
                </ListItemButton>
              </ListItem>
            </List>
          </Box>
        </Drawer>
      </Box>
    </>
  );
};

export default Sidebar;
